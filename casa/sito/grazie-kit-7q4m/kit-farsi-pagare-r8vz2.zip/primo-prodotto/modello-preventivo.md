**[Il tuo nome o ragione sociale]**
[Indirizzo] · P.IVA [numero] · [email] · [telefono] · PEC [indirizzo PEC]

---

# Preventivo n. [anno]-[numero]

**Data:** [gg/mm/aaaa]  
**Valido fino al:** [gg/mm/aaaa] (30 giorni)

**Cliente:** [ragione sociale / nome]  
[Indirizzo] · P.IVA / C.F. [numero] · Referente: [nome], [email]

---

## 1. Oggetto

[Una o due frasi che descrivono il risultato finale, non le attività. Esempio: "Realizzazione del sito web aziendale di 5 pagine, pronto alla pubblicazione sul dominio del cliente."]

## 2. Cosa è incluso

- [Attività o consegna 1]
- [Attività o consegna 2]
- [Attività o consegna 3]
- [N] revisioni comprese

## 3. Cosa non è incluso

- [Esempio: testi e fotografie, che fornisce il cliente]
- [Esempio: costi di terze parti (hosting, licenze, stampa)]
- Revisioni oltre le [N] comprese: [tariffa] € l'ora / a corpo, previa conferma scritta

## 4. Tempi

- Avvio: alla ricezione dell'acconto
- [Fase 1]: entro [N] giorni lavorativi dall'avvio
- Consegna finale: entro [N] giorni lavorativi dall'avvio

I tempi si allungano dei giorni di attesa di materiali o riscontri da parte del cliente.

## 5. Compenso

| Voce | Importo |
|---|---:|
| [Voce 1] | [importo] € |
| [Voce 2] | [importo] € |
| **Totale imponibile** | **[importo] €** |
| [IVA 22% / Rivalsa INPS 4% / Contributo cassa, se applicabili] | [importo] € |
| **Totale** | **[importo] €** |

[Se sei in regime forfettario: "Operazione in franchigia da IVA ai sensi dell'art. 1, commi 54-89, L. 190/2014". Verifica la dicitura con il tuo commercialista.]

## 6. Pagamento

- **[40]% all'accettazione** del preventivo, a fronte di fattura: [importo] €
- **Saldo alla consegna**, entro [30] giorni dalla data della fattura: [importo] €

Bonifico bancario: IBAN [IBAN], intestato a [nome].

In caso di ritardato pagamento si applicano, senza necessità di costituzione in mora, gli interessi moratori previsti dal D.Lgs. 231/2002 e l'importo forfettario di 40 € per i costi di recupero (art. 6). *[Togli questo paragrafo se il cliente è un privato consumatore.]*

## 7. Consegna, accettazione e diritti

Il lavoro si intende consegnato con l'invio dei file finali all'indirizzo email del cliente. In assenza di contestazioni scritte e motivate entro [7] giorni, il lavoro si intende accettato.

I diritti di utilizzo del materiale consegnato passano al cliente con il saldo completo del compenso.

## 8. Accettazione

Per accettare questo preventivo, restituiscilo firmato oppure rispondi all'email con: "Accetto il preventivo n. [anno]-[numero]".

&nbsp;

Luogo e data ______________________

Firma del cliente per accettazione ______________________
