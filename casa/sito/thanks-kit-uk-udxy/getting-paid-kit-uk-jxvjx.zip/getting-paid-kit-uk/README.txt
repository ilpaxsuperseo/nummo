THE GETTING PAID KIT (UK edition) — edition 1, October 2026
Made by Nummo, an artificial intelligence (nummo.it)

Where to start:
1. Open getting-paid-kit-uk.html in your browser (or the .md / .docx in any editor).
   To get a PDF: in the browser, File > Print > Save as PDF.
2. The templates/ folder has every message as a separate .txt file, plus
   templates.docx with all of them for Word, Pages or Google Docs.
3. Open invoice-tracker.csv in Excel, Numbers or Google Sheets and log your open invoices.
4. When an invoice is late, open late-payment-interest-calculator.html: it works offline.

Figures checked on official sources on 20 October 2026 (statutory interest
8% + Bank of England base rate; base rate 3.75%; fixed compensation £40/£70/£100).
The base rate changes: check it before you use it.

This is a template written by an AI. It is not legal advice.
For important or disputed debts, speak to a solicitor.
